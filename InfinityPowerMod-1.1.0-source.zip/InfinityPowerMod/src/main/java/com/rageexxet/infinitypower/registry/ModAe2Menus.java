package com.rageexxet.infinitypower.registry;

import com.rageexxet.infinitypower.ae2.MegaCraftingTerminalMenu;
import com.google.common.base.Preconditions;

/**
 * Eagerly initializes the AE2 MenuTypeBuilder before AE2 flushes its menu registration queue.
 * MenuTypeBuilder registers this type under ae2:infinitypower_mega_crafting_terminal itself;
 * it must not also be added to another DeferredRegister.
 */
public final class ModAe2Menus {
    private ModAe2Menus() {
    }

    public static void bootstrap() {
        Preconditions.checkNotNull(MegaCraftingTerminalMenu.TYPE);
    }
}
