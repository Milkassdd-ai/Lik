package com.rageexxet.infinitypower.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class InfinityConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue DAMAGE_ENTITIES;
    public static final ForgeConfigSpec.BooleanValue FLATTEN_TERRAIN;
    public static final ForgeConfigSpec.IntValue PLATE_RADIUS_BLOCKS;
    public static final ForgeConfigSpec.IntValue COLUMNS_PER_TICK;
    public static final ForgeConfigSpec.IntValue BLOCK_UPDATES_PER_TICK;
    public static final ForgeConfigSpec.IntValue MAX_QUEUED_FLATTEN_JOBS;

    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.push("explosive_plate");
        DAMAGE_ENTITIES = BUILDER.comment("Damage entities inside the plate blast radius.")
                .define("damageEntities", true);
        FLATTEN_TERRAIN = BUILDER.comment("Flatten terrain around the impact point.")
                .define("flattenTerrain", true);
        PLATE_RADIUS_BLOCKS = BUILDER.comment("Horizontal radius in blocks. 80 blocks = 5 chunks.")
                .defineInRange("radiusBlocks", 80, 1, 256);
        COLUMNS_PER_TICK = BUILDER.comment("Maximum terrain columns started per server tick across all pending plate detonations.")
                .defineInRange("columnsPerTick", 96, 1, 1024);
        BLOCK_UPDATES_PER_TICK = BUILDER.comment("Maximum terrain block positions examined/updated per server tick; lower this if a server stutters.")
                .defineInRange("blockUpdatesPerTick", 2048, 1, 65536);
        MAX_QUEUED_FLATTEN_JOBS = BUILDER.comment("Maximum pending terrain-flattening jobs.")
                .defineInRange("maxQueuedJobs", 2, 1, 8);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    private InfinityConfig() {}
}
