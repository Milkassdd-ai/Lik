package com.rageexxet.infinitypower.entity;

import com.rageexxet.infinitypower.registry.ModEntities;
import com.rageexxet.infinitypower.registry.ModItems;
import com.rageexxet.infinitypower.world.InfinityBlast;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.HitResult;

public final class ExplosivePlateEntity extends ThrowableItemProjectile {
    public ExplosivePlateEntity(EntityType<? extends ExplosivePlateEntity> type, Level level) {
        super(type, level);
    }

    public ExplosivePlateEntity(Level level, LivingEntity shooter) {
        super(ModEntities.EXPLOSIVE_PLATE.get(), shooter, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.EXPLOSIVE_PLATE.get();
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
            BlockPos impactBlock = BlockPos.containing(result.getLocation());
            InfinityBlast.detonate(serverLevel, result.getLocation(), impactBlock, this.getOwner(), this);
            this.discard();
        }
    }
}
