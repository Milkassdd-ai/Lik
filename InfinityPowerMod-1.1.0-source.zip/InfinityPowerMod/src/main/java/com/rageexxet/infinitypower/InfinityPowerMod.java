package com.rageexxet.infinitypower;

import com.rageexxet.infinitypower.config.InfinityConfig;
import com.rageexxet.infinitypower.registry.ModAe2Menus;
import com.rageexxet.infinitypower.registry.ModEntities;
import com.rageexxet.infinitypower.registry.ModItems;
import com.rageexxet.infinitypower.registry.ModParts;
import com.rageexxet.infinitypower.registry.ModTabs;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(InfinityPowerMod.MOD_ID)
public final class InfinityPowerMod {
    public static final String MOD_ID = "infinitypower";

    public InfinityPowerMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModAe2Menus.bootstrap();
        ModItems.ITEMS.register(modBus);
        ModParts.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModTabs.TABS.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, InfinityConfig.SPEC,
                "infinitypower-common.toml");
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
