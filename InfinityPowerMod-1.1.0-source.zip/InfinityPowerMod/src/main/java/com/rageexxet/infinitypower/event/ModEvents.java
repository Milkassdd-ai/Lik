package com.rageexxet.infinitypower.event;

import com.rageexxet.infinitypower.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "infinitypower", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ModEvents {
    private static final ThreadLocal<Boolean> AREA_BREAK_GUARD = ThreadLocal.withInitial(() -> false);
    private static final int WIDTH = 16;
    private static final int DEPTH = 6;

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (event.isCanceled()) return;
        if (AREA_BREAK_GUARD.get()) return;
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (player.isSpectator()) return;
        if (player.getMainHandItem().getItem() != ModItems.INFINITY_PICKAXE.get()) return;

        BlockPos origin = event.getPos();
        Direction forward = Direction.getNearest(player.getLookAngle().x, player.getLookAngle().y, player.getLookAngle().z);
        Direction[] planeAxes = perpendicularAxes(forward);
        Direction axisA = planeAxes[0];
        Direction axisB = planeAxes[1];
        int half = WIDTH / 2;

        AREA_BREAK_GUARD.set(true);
        try {
            for (int depth = 0; depth < DEPTH; depth++) {
                for (int a = -half; a < WIDTH - half; a++) {
                    for (int b = -half; b < WIDTH - half; b++) {
                        BlockPos target = origin.relative(forward, depth).relative(axisA, a).relative(axisB, b);
                        if (target.equals(origin)) continue; // The original block is handled by vanilla.
                        if (!level.hasChunkAt(target)) continue;

                        BlockState state = level.getBlockState(target);
                        if (state.isAir() || state.getDestroySpeed(level, target) < 0.0F) continue;
                        // Use the server's normal break path so permissions and protection mods can cancel it.
                        player.gameMode.destroyBlock(target);
                    }
                }
            }
        } finally {
            AREA_BREAK_GUARD.set(false);
        }
    }

    private static Direction[] perpendicularAxes(Direction forward) {
        return switch (forward.getAxis()) {
            case X -> new Direction[]{Direction.UP, Direction.SOUTH};
            case Y -> new Direction[]{Direction.EAST, Direction.SOUTH};
            case Z -> new Direction[]{Direction.UP, Direction.EAST};
        };
    }

    private ModEvents() {}
}
