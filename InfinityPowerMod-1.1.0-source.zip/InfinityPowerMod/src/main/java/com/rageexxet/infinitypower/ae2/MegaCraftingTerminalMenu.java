package com.rageexxet.infinitypower.ae2;

import appeng.api.inventories.ISegmentedInventory;
import appeng.api.inventories.InternalInventory;
import appeng.api.stacks.AEItemKey;
import appeng.core.sync.network.NetworkHandler;
import appeng.core.sync.packets.InventoryActionPacket;
import appeng.helpers.IMenuCraftingPacket;
import appeng.helpers.IMenuCraftingPacket.AutoCraftEntry;
import appeng.helpers.InventoryAction;
import appeng.menu.SlotSemantic;
import appeng.menu.SlotSemantics;
import appeng.menu.implementations.MenuTypeBuilder;
import appeng.menu.me.common.MEStorageMenu;
import appeng.menu.me.crafting.CraftConfirmMenu;
import appeng.menu.slot.CraftingMatrixSlot;
import com.google.common.base.Preconditions;
import com.rageexxet.infinitypower.InfinityPowerMod;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import appeng.api.storage.ITerminalHost;
import appeng.core.AppEng;
import appeng.parts.reporting.CraftingTerminalPart;
import appeng.util.inv.PlayerInternalInventory;

import java.util.List;

/**
 * AE2's normal storage terminal menu with a persistent 5x5 recipe matrix.
 */
public final class MegaCraftingTerminalMenu extends MEStorageMenu implements IMenuCraftingPacket {
    public static final MenuType<MegaCraftingTerminalMenu> TYPE = MenuTypeBuilder
            .<MegaCraftingTerminalMenu, ITerminalHost>create(MegaCraftingTerminalMenu::new, ITerminalHost.class)
            .build("infinitypower_mega_crafting_terminal");

    private static final String ACTION_CLEAR_TO_PLAYER = "infinitypower$clearToPlayer";

    public static final SlotSemantic[] GRID_ROW_SEMANTICS = {
            SlotSemantics.register("INFINITYPOWER_CRAFTING_GRID_ROW_1", false),
            SlotSemantics.register("INFINITYPOWER_CRAFTING_GRID_ROW_2", false),
            SlotSemantics.register("INFINITYPOWER_CRAFTING_GRID_ROW_3", false),
            SlotSemantics.register("INFINITYPOWER_CRAFTING_GRID_ROW_4", false),
            SlotSemantics.register("INFINITYPOWER_CRAFTING_GRID_ROW_5", false)
    };

    private final ISegmentedInventory craftingInventoryHost;
    private final CraftingMatrixSlot[] craftingSlots = new CraftingMatrixSlot[MegaCraftingTerminalPart.GRID_SIZE];
    private final CraftingContainer recipeTestContainer = new TransientCraftingContainer(this,
            MegaCraftingTerminalPart.GRID_SIDE, MegaCraftingTerminalPart.GRID_SIDE);
    private final FiveByFiveCraftingSlot outputSlot;
    private Recipe<CraftingContainer> currentRecipe;

    public MegaCraftingTerminalMenu(int id, Inventory playerInventory, ITerminalHost host) {
        super(TYPE, id, playerInventory, host);
        this.craftingInventoryHost = (ISegmentedInventory) host;

        InternalInventory craftingGrid = this.craftingInventoryHost.getSubInventory(MegaCraftingTerminalPart.INV_CRAFTING);
        Preconditions.checkState(craftingGrid != null && craftingGrid.size() == MegaCraftingTerminalPart.GRID_SIZE,
                "The ME 5x5 terminal host must expose a 25-slot crafting inventory");

        for (int row = 0; row < MegaCraftingTerminalPart.GRID_SIDE; row++) {
            for (int column = 0; column < MegaCraftingTerminalPart.GRID_SIDE; column++) {
                int index = row * MegaCraftingTerminalPart.GRID_SIDE + column;
                this.addSlot(this.craftingSlots[index] = new CraftingMatrixSlot(this, craftingGrid, index),
                        GRID_ROW_SEMANTICS[row]);
            }
        }

        this.addSlot(this.outputSlot = new FiveByFiveCraftingSlot(getPlayer(), getActionSource(), this.powerSource,
                this.storage, craftingGrid, this), SlotSemantics.CRAFTING_RESULT);

        registerClientAction(ACTION_CLEAR_TO_PLAYER, this::clearToPlayerInventory);
        updateCurrentRecipeAndOutput(true);
    }

    @Override
    public void slotsChanged(Container inventory) {
        if (inventory != recipeTestContainer) {
            updateCurrentRecipeAndOutput(false);
        }
    }

    private void updateCurrentRecipeAndOutput(boolean forceUpdate) {
        boolean changed = forceUpdate;
        for (int index = 0; index < craftingSlots.length; index++) {
            ItemStack stack = craftingSlots[index].getItem();
            if (!ItemStack.isSameItemSameTags(stack, recipeTestContainer.getItem(index))) {
                recipeTestContainer.setItem(index, stack.copy());
                changed = true;
            }
        }

        if (!changed) {
            return;
        }

        Level level = getPlayer().level();
        currentRecipe = level.getRecipeManager()
                .getRecipeFor(RecipeType.CRAFTING, recipeTestContainer, level)
                .orElse(null);

        if (currentRecipe == null) {
            outputSlot.set(ItemStack.EMPTY);
        } else {
            outputSlot.set(currentRecipe.assemble(recipeTestContainer, level.registryAccess()));
        }
    }

    public Recipe<CraftingContainer> getCurrentRecipe() {
        return currentRecipe;
    }

    @Override
    public InternalInventory getCraftingMatrix() {
        return craftingInventoryHost.getSubInventory(MegaCraftingTerminalPart.INV_CRAFTING);
    }

    @Override
    public boolean useRealItems() {
        return true;
    }

    @Override
    public void startAutoCrafting(List<AutoCraftEntry> toCraft) {
        CraftConfirmMenu.openWithCraftingList(getActionHost(), (ServerPlayer) getPlayer(), getLocator(), toCraft);
    }

    @Override
    public boolean hasIngredient(Ingredient ingredient, Object2IntOpenHashMap<Object> reservedAmounts) {
        for (CraftingMatrixSlot slot : craftingSlots) {
            ItemStack stack = slot.getItem();
            if (!stack.isEmpty() && ingredient.test(stack)) {
                int reserved = reservedAmounts.getOrDefault(slot, 0);
                if (stack.getCount() > reserved) {
                    reservedAmounts.merge(slot, 1, Integer::sum);
                    return true;
                }
            }
        }
        return super.hasIngredient(ingredient, reservedAmounts);
    }

    /** Return the entire 5x5 matrix to ME storage. Must be called on the client. */
    public void clearCraftingGrid() {
        Preconditions.checkState(isClientSide());
        for (SlotSemantic rowSemantic : GRID_ROW_SEMANTICS) {
            List<net.minecraft.world.inventory.Slot> rowSlots = getSlots(rowSemantic);
            if (!rowSlots.isEmpty()) {
                NetworkHandler.instance().sendToServer(new InventoryActionPacket(
                        InventoryAction.MOVE_REGION, rowSlots.get(0).index, 0));
            }
        }
    }

    /** Move all possible matrix items into the player's inventory. */
    public void clearToPlayerInventory() {
        if (isClientSide()) {
            sendClientAction(ACTION_CLEAR_TO_PLAYER);
            return;
        }

        InternalInventory grid = getCraftingMatrix();
        PlayerInternalInventory playerInventory = new PlayerInternalInventory(getPlayerInventory());
        for (int matrixSlot = 0; matrixSlot < grid.size(); matrixSlot++) {
            for (int emptyPass = 0; emptyPass < 2; emptyPass++) {
                boolean allowEmpty = emptyPass == 1;
                for (int playerSlot = 9; playerSlot-- > 0;) {
                    if (playerInventory.getStackInSlot(playerSlot).isEmpty() == allowEmpty) {
                        grid.setItemDirect(matrixSlot,
                                playerInventory.getSlotInv(playerSlot).addItems(grid.getStackInSlot(matrixSlot)));
                    }
                }
                for (int playerSlot = 9; playerSlot < Inventory.INVENTORY_SIZE; playerSlot++) {
                    if (playerInventory.getStackInSlot(playerSlot).isEmpty() == allowEmpty) {
                        grid.setItemDirect(matrixSlot,
                                playerInventory.getSlotInv(playerSlot).addItems(grid.getStackInSlot(matrixSlot)));
                    }
                }
            }
        }
        slotsChanged(grid.toContainer());
    }
}
