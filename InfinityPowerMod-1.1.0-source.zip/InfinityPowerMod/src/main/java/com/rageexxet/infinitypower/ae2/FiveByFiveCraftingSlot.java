package com.rageexxet.infinitypower.ae2;

import appeng.api.config.Actionable;
import appeng.api.config.PowerMultiplier;
import appeng.api.inventories.InternalInventory;
import appeng.api.networking.energy.IEnergySource;
import appeng.api.networking.security.IActionSource;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.KeyCounter;
import appeng.api.storage.MEStorage;
import appeng.crafting.CraftingEvent;
import appeng.helpers.IMenuCraftingPacket;
import appeng.helpers.InventoryAction;
import appeng.items.storage.ViewCellItem;
import appeng.menu.slot.CraftingTermSlot;
import appeng.util.Platform;
import appeng.util.inv.CarriedItemInventory;
import appeng.util.inv.PlayerInternalInventory;
import appeng.util.prioritylist.IPartitionList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.ForgeHooks;

import java.util.Arrays;
import java.util.List;

/**
 * AE2 result slot adapted to assemble, refill, and consume a 5x5 crafting matrix.
 * The grid inventory remains on the terminal part; ingredients pulled for refills are extracted from ME storage.
 */
public final class FiveByFiveCraftingSlot extends CraftingTermSlot {
    private final InternalInventory matrix;
    private final IActionSource actionSource;
    private final IEnergySource energySource;
    private final MEStorage storage;
    private final IMenuCraftingPacket craftingMenu;

    public FiveByFiveCraftingSlot(Player player, IActionSource actionSource, IEnergySource energySource,
            MEStorage storage, InternalInventory matrix, IMenuCraftingPacket craftingMenu) {
        super(player, actionSource, energySource, storage, matrix, matrix, craftingMenu);
        this.matrix = matrix;
        this.actionSource = actionSource;
        this.energySource = energySource;
        this.storage = storage;
        this.craftingMenu = craftingMenu;
    }

    @Override
    public void doClick(InventoryAction action, Player player) {
        ItemStack shownOutput = getItem();
        if (shownOutput.isEmpty() || isRemote()) {
            return;
        }

        int maxTimes;
        InternalInventory target;
        if (action == InventoryAction.CRAFT_SHIFT || action == InventoryAction.CRAFT_ALL) {
            target = new PlayerInternalInventory(player.getInventory());
            if (action == InventoryAction.CRAFT_SHIFT) {
                maxTimes = (int) Math.floor((double) shownOutput.getMaxStackSize() / shownOutput.getCount());
            } else {
                maxTimes = (int) Math.floor((double) shownOutput.getMaxStackSize() / shownOutput.getCount()
                        * Inventory.INVENTORY_SIZE);
            }
        } else if (action == InventoryAction.CRAFT_STACK) {
            target = new CarriedItemInventory(getMenu());
            maxTimes = (int) Math.floor((double) shownOutput.getMaxStackSize() / shownOutput.getCount());
        } else {
            if (getMenu().getCarried().isEmpty()) {
                ItemStack crafted = craftOnce(player);
                if (!crafted.isEmpty()) {
                    getMenu().setCarried(crafted);
                }
                return;
            }
            target = new CarriedItemInventory(getMenu());
            maxTimes = 1;
        }

        ItemStack itemAtStart = shownOutput.copy();
        for (int count = 0; count < maxTimes; count++) {
            if (!ItemStack.isSameItemSameTags(itemAtStart, getItem())) {
                return;
            }
            if (!target.simulateAdd(itemAtStart).isEmpty()) {
                return;
            }

            ItemStack crafted = craftOnce(player);
            if (crafted.isEmpty()) {
                return;
            }
            ItemStack remainder = target.addItems(crafted);
            if (!remainder.isEmpty()) {
                Platform.spawnDrops(player.level(), player.blockPosition(), List.of(remainder));
                return;
            }
        }
    }

    private ItemStack craftOnce(Player player) {
        if (player.level().isClientSide()) {
            return ItemStack.EMPTY;
        }

        Level level = player.level();
        ItemStack displayedOutput = getItem().copy();
        if (displayedOutput.isEmpty()) {
            return ItemStack.EMPTY;
        }

        TransientCraftingContainer input = new TransientCraftingContainer(getMenu(),
                MegaCraftingTerminalPart.GRID_SIDE, MegaCraftingTerminalPart.GRID_SIDE);
        for (int index = 0; index < matrix.size(); index++) {
            input.setItem(index, matrix.getStackInSlot(index).copy());
        }

        Recipe<CraftingContainer> recipe = findRecipe(input, level);
        if (recipe == null || !recipe.matches(input, level)) {
            return ItemStack.EMPTY;
        }

        ItemStack result = recipe.assemble(input, level.registryAccess());
        if (result.isEmpty() || !ItemStack.isSameItemSameTags(displayedOutput, result)) {
            return ItemStack.EMPTY;
        }

        ItemStack[] refills = new ItemStack[matrix.size()];
        Arrays.fill(refills, ItemStack.EMPTY);

        if (storage != null && energySource != null) {
            KeyCounter available = storage.getAvailableStacks();
            IPartitionList filter = ViewCellItem.createItemFilter(craftingMenu.getViewCells());
            for (int index = 0; index < matrix.size(); index++) {
                ItemStack template = matrix.getStackInSlot(index);
                if (!template.isEmpty()) {
                    refills[index] = Platform.extractItemsByRecipe(energySource, actionSource, storage, level,
                            recipe, result, input, template, index, available, Actionable.MODULATE, filter);
                    if (!refills[index].isEmpty()) {
                        input.setItem(index, refills[index].copy());
                    }
                }
            }
        }

        // Compute container remainders from the ingredients that were actually in the matrix before this craft.
        TransientCraftingContainer consumedInput = new TransientCraftingContainer(getMenu(),
                MegaCraftingTerminalPart.GRID_SIDE, MegaCraftingTerminalPart.GRID_SIDE);
        for (int index = 0; index < matrix.size(); index++) {
            consumedInput.setItem(index, matrix.getStackInSlot(index).copy());
        }

        NonNullList<ItemStack> remaining;
        ForgeHooks.setCraftingPlayer(player);
        try {
            remaining = recipe.getRemainingItems(consumedInput);
        } finally {
            ForgeHooks.setCraftingPlayer(null);
        }

        CraftingEvent.fireCraftingEvent(player, result, matrix.toContainer());
        super.onQuickCraft(result, result.getCount());

        for (int index = 0; index < matrix.size(); index++) {
            matrix.extractItem(index, 1, false);
            ItemStack remainder = index < remaining.size() ? remaining.get(index).copy() : ItemStack.EMPTY;
            if (!remainder.isEmpty()) {
                if (matrix.getStackInSlot(index).isEmpty()) {
                    matrix.setItemDirect(index, remainder);
                } else if (!player.getInventory().add(remainder)) {
                    player.drop(remainder, false);
                }
            }
        }

        for (int index = 0; index < matrix.size(); index++) {
            ItemStack refill = refills[index];
            if (refill.isEmpty()) {
                continue;
            }

            if (matrix.getStackInSlot(index).isEmpty()) {
                matrix.setItemDirect(index, refill);
            } else if (storage != null) {
                AEItemKey key = AEItemKey.of(refill);
                long inserted = storage.insert(key, refill.getCount(), Actionable.MODULATE, actionSource);
                if (inserted < refill.getCount()) {
                    ItemStack extra = key.toStack((int) (refill.getCount() - inserted));
                    Platform.spawnDrops(player.level(), player.blockPosition(), List.of(extra));
                }
            } else {
                Platform.spawnDrops(player.level(), player.blockPosition(), List.of(refill));
            }
        }

        player.containerMenu.slotsChanged(matrix.toContainer());
        return result;
    }

    @Override
    protected Recipe<CraftingContainer> findRecipe(CraftingContainer input, Level level) {
        if (craftingMenu instanceof MegaCraftingTerminalMenu terminalMenu) {
            Recipe<CraftingContainer> selected = terminalMenu.getCurrentRecipe();
            if (selected != null && selected.matches(input, level)) {
                return selected;
            }
        }
        return level.getRecipeManager().getRecipeFor(RecipeType.CRAFTING, input, level).orElse(null);
    }
}
