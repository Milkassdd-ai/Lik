from pathlib import Path
import json
import shutil

ROOT = Path(__file__).parent
ASSETS = ROOT / 'src/main/resources/assets/infinitypower'
ITEM_MODELS = ASSETS / 'models/item'
ITEM_TEXTURES = ASSETS / 'textures/item'
ART = ROOT / 'art'
for folder in (ITEM_MODELS, ITEM_TEXTURES, ART):
    folder.mkdir(parents=True, exist_ok=True)


def find_source(home_name: str, art_names: tuple[str, ...]) -> Path:
    home_path = Path('/home/user') / home_name
    if home_path.exists():
        return home_path
    for art_name in art_names:
        candidate = ART / art_name
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f'Missing {home_name}; expected it under /home/user or {ART}')


def copy_unless_same(source: Path, destination: Path) -> None:
    if source.resolve() != destination.resolve():
        shutil.copy2(source, destination)


# Rainbow Infinity Pickaxe: export a static Java item mesh, while preserving the
# animated Blockbench project (both clips) as editable source under /art.
pickaxe_bb = find_source('rainbow_infinity_pickaxe.bbmodel', ('rainbow_infinity_pickaxe_animated.bbmodel', 'rainbow_infinity_pickaxe.bbmodel'))
pickaxe_texture = find_source('infinity_pickaxe_texture.png', ('infinity_pickaxe_texture.png',))
pickaxe_art = ART / 'rainbow_infinity_pickaxe_animated.bbmodel'
copy_unless_same(pickaxe_bb, pickaxe_art)
copy_unless_same(pickaxe_texture, ART / 'infinity_pickaxe_texture.png')
shutil.copy2(pickaxe_texture, ITEM_TEXTURES / 'infinity_pickaxe.png')

pickaxe_display = {
    'thirdperson_righthand': {'rotation':[75,45,0], 'translation':[0,2,0], 'scale':[0.55,0.55,0.55]},
    'thirdperson_lefthand': {'rotation':[75,45,0], 'translation':[0,2,0], 'scale':[0.55,0.55,0.55]},
    'firstperson_righthand': {'rotation':[0,45,0], 'translation':[1,2,1], 'scale':[0.65,0.65,0.65]},
    'firstperson_lefthand': {'rotation':[0,225,0], 'translation':[1,2,1], 'scale':[0.65,0.65,0.65]},
    'gui': {'rotation':[30,225,0], 'translation':[0,0,0], 'scale':[0.72,0.72,0.72]},
    'ground': {'rotation':[0,0,0], 'translation':[0,2,0], 'scale':[0.5,0.5,0.5]},
    'fixed': {'rotation':[0,0,0], 'translation':[0,0,0], 'scale':[0.55,0.55,0.55]},
}
static_elements = []
for element in json.loads(pickaxe_bb.read_text(encoding='utf-8'))['elements']:
    faces = {}
    for direction, face in element['faces'].items():
        if face.get('texture') is None:
            continue
        faces[direction] = {'uv': face['uv'], 'texture': '#0'}
    static_elements.append({'from': element['from'], 'to': element['to'], 'faces': faces})
pickaxe_model = {
    'credit': 'Infinity Power — Blockbench model export; animated source in /art',
    'texture_size': [64,64],
    'textures': {'0':'infinitypower:item/infinity_pickaxe', 'particle':'infinitypower:item/infinity_pickaxe'},
    'elements': static_elements,
    'display': pickaxe_display,
}
(ITEM_MODELS / 'infinity_pickaxe.json').write_text(json.dumps(pickaxe_model, indent=2), encoding='utf-8')

# Use the user's original Blockbench PCB geometry, Java item export and pixel texture.
pcb_bb = find_source('handheld_pixel_pcb.bbmodel', ('handheld_pixel_pcb.bbmodel',))
pcb_java_model = find_source('handheld_pixel_pcb_java_item.json', ('handheld_pixel_pcb_java_item.json',))
pcb_texture = find_source('handheld_pcb_texture.png', ('handheld_pcb_texture.png',))
copy_unless_same(pcb_bb, ART / 'handheld_pixel_pcb.bbmodel')
copy_unless_same(pcb_java_model, ART / 'handheld_pixel_pcb_java_item.json')
copy_unless_same(pcb_texture, ART / 'handheld_pcb_texture.png')
shutil.copy2(pcb_texture, ITEM_TEXTURES / 'explosive_plate.png')
pcb_model = json.loads(pcb_java_model.read_text(encoding='utf-8'))
pcb_model['credit'] = 'Infinity Power — based on the Blockbench handheld pixel PCB model'
pcb_model['textures'] = {
    '0':'infinitypower:item/explosive_plate',
    'particle':'infinitypower:item/explosive_plate',
}
(ITEM_MODELS / 'explosive_plate.json').write_text(json.dumps(pcb_model, indent=2), encoding='utf-8')

print('Exported pickaxe and PCB item models/textures into', ASSETS)
