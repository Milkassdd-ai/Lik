package com.rageexxet.infinitypower.registry;

import com.rageexxet.infinitypower.InfinityPowerMod;
import com.rageexxet.infinitypower.entity.ExplosivePlateEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, InfinityPowerMod.MOD_ID);

    public static final RegistryObject<EntityType<ExplosivePlateEntity>> EXPLOSIVE_PLATE = ENTITY_TYPES.register("explosive_plate",
            () -> EntityType.Builder.<ExplosivePlateEntity>of(ExplosivePlateEntity::new, MobCategory.MISC)
                    .sized(0.35F, 0.35F)
                    .clientTrackingRange(8)
                    .updateInterval(10)
                    .build(InfinityPowerMod.MOD_ID + ":explosive_plate"));

    private ModEntities() {}
}
