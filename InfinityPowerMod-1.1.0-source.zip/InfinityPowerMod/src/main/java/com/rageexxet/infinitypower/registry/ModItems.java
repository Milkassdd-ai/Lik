package com.rageexxet.infinitypower.registry;

import com.rageexxet.infinitypower.InfinityPowerMod;
import com.rageexxet.infinitypower.item.ExplosivePlateItem;
import com.rageexxet.infinitypower.item.InfinityPickaxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, InfinityPowerMod.MOD_ID);

    public static final RegistryObject<Item> INFINITY_PICKAXE = ITEMS.register("infinity_pickaxe",
            () -> new InfinityPickaxeItem(new Item.Properties().stacksTo(1).durability(1_000_000).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> EXPLOSIVE_PLATE = ITEMS.register("explosive_plate",
            () -> new ExplosivePlateItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC)));

    private ModItems() {}
}
