package com.rageexxet.infinitypower.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import java.util.List;

public final class InfinityPickaxeItem extends PickaxeItem {
    private static final Tier INFINITY_TIER = new Tier() {
        @Override public int getUses() { return 1_000_000; }
        @Override public float getSpeed() { return 18.0F; }
        @Override public float getAttackDamageBonus() { return 8.0F; }
        @Override public int getLevel() { return 5; }
        @Override public int getEnchantmentValue() { return 45; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.NETHER_STAR); }
    };

    public InfinityPickaxeItem(Item.Properties properties) {
        super(INFINITY_TIER, 7, -2.7F, properties);
    }

    @Override
    public int getEnchantmentValue() {
        return 45;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void onCraftedBy(ItemStack stack, Level level, Player player) {
        super.onCraftedBy(stack, level, player);
        if (!level.isClientSide && !stack.getOrCreateTag().getBoolean("infinitypower_default_enchants")) {
            stack.enchant(Enchantments.BLOCK_EFFICIENCY, 5);
            stack.enchant(Enchantments.UNBREAKING, 3);
            stack.enchant(Enchantments.BLOCK_FORTUNE, 3);
            stack.enchant(Enchantments.MENDING, 1);
            stack.getOrCreateTag().putBoolean("infinitypower_default_enchants", true);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.infinitypower.pickaxe_area").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.infinitypower.pickaxe_depth").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.infinitypower.pickaxe_enchants").withStyle(ChatFormatting.LIGHT_PURPLE));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
