package com.rageexxet.infinitypower.registry;

import com.rageexxet.infinitypower.InfinityPowerMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, InfinityPowerMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> INFINITY_TAB = TABS.register("infinity_tab", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.infinitypower"))
                    .icon(() -> new ItemStack(ModItems.INFINITY_PICKAXE.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.INFINITY_PICKAXE.get());
                        output.accept(ModItems.EXPLOSIVE_PLATE.get());
                        output.accept(ModParts.MEGA_CRAFTING_TERMINAL.get());
                    })
                    .build());

    private ModTabs() {}
}
