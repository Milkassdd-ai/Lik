from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1] / "src/main/resources/assets/infinitypower/textures"
PART = ROOT / "part"
GUI = ROOT / "guis"
PART.mkdir(parents=True, exist_ok=True)
GUI.mkdir(parents=True, exist_ok=True)

# Original 16x16 pixel-art textures for the AE2 cable-bus terminal.
front = Image.new("RGBA", (16, 16), (5, 13, 19, 255))
d = ImageDraw.Draw(front)
d.rectangle((1, 1, 14, 14), fill=(15, 28, 35, 255), outline=(39, 75, 81, 255))
d.rectangle((2, 2, 13, 13), fill=(7, 20, 28, 255), outline=(17, 205, 195, 255))
# Bright top and bottom rails.
d.line((3, 3, 12, 3), fill=(113, 255, 234, 255))
d.line((3, 12, 12, 12), fill=(22, 128, 137, 255))
# Tiny 5x5 matrix glyph in the display.
palette = [
    (89, 255, 226, 255), (39, 185, 204, 255), (35, 118, 160, 255), (94, 226, 191, 255), (41, 145, 178, 255),
    (31, 134, 153, 255), (92, 242, 222, 255), (48, 157, 181, 255), (44, 112, 145, 255), (122, 249, 219, 255),
    (62, 177, 187, 255), (35, 111, 148, 255), (120, 255, 226, 255), (46, 168, 171, 255), (45, 117, 157, 255),
    (117, 236, 207, 255), (47, 129, 164, 255), (59, 206, 194, 255), (40, 119, 151, 255), (108, 238, 215, 255),
    (46, 148, 166, 255), (117, 255, 224, 255), (43, 127, 165, 255), (74, 203, 196, 255), (44, 142, 164, 255),
]
for i, color in enumerate(palette):
    x = 4 + (i % 5) * 2
    y = 4 + (i // 5) * 2
    front.putpixel((x, y), color)
# Two tiny status marks, keeping the face readable at inventory scale.
d.point((3, 6), fill=(255, 185, 82, 255))
d.point((12, 10), fill=(116, 255, 227, 255))
front.save(PART / "mega_terminal_front.png")

sides = Image.new("RGBA", (16, 16), (14, 26, 33, 255))
d = ImageDraw.Draw(sides)
d.rectangle((0, 0, 15, 15), fill=(20, 31, 37, 255))
d.line((1, 1, 1, 14), fill=(65, 88, 91, 255))
d.line((2, 2, 2, 13), fill=(12, 18, 23, 255))
d.line((13, 2, 13, 13), fill=(29, 147, 146, 255))
d.line((14, 1, 14, 14), fill=(66, 92, 94, 255))
d.rectangle((5, 4, 10, 11), fill=(10, 18, 24, 255), outline=(42, 70, 75, 255))
d.point((7, 7), fill=(52, 217, 201, 255))
sides.save(PART / "mega_terminal_sides.png")

back = Image.new("RGBA", (16, 16), (19, 30, 37, 255))
d = ImageDraw.Draw(back)
d.rectangle((1, 1, 14, 14), fill=(24, 37, 43, 255), outline=(70, 95, 98, 255))
d.rectangle((3, 3, 12, 12), fill=(9, 19, 26, 255), outline=(37, 89, 91, 255))
d.rectangle((5, 5, 10, 10), fill=(13, 35, 42, 255), outline=(27, 184, 175, 255))
d.rectangle((6, 6, 9, 9), fill=(6, 18, 26, 255))
d.line((7, 7, 8, 7), fill=(84, 255, 220, 255))
for xy in [(2, 2), (13, 2), (2, 13), (13, 13)]:
    d.point(xy, fill=(149, 177, 173, 255))
back.save(PART / "mega_terminal_back.png")

# Transparent front overlays used for the network/status glow.
for name, col in [
    ("mega_terminal_lights_bright.png", (100, 255, 225, 178)),
    ("mega_terminal_lights_medium.png", (34, 205, 196, 115)),
    ("mega_terminal_lights_dark.png", (12, 100, 112, 72)),
]:
    layer = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    # A restrained angular halo; transparent outside the LED marks.
    ld.point((3, 3), fill=col)
    ld.point((12, 3), fill=col)
    ld.point((3, 12), fill=col)
    ld.point((12, 12), fill=col)
    ld.line((5, 2, 10, 2), fill=col)
    ld.point((11, 7), fill=col)
    layer.save(PART / name)

# 380px-wide terminal skin. AE2 slices this into header, storage rows, and a bottom section;
# the right rail is intentionally tileable so the crafting area stays clean at any terminal height.
W, H = 380, 186
img = Image.new("RGBA", (W, H), (7, 15, 22, 255))
d = ImageDraw.Draw(img)

# Main surface and layered metal frame.
d.rectangle((0, 0, W - 1, H - 1), fill=(7, 16, 23, 255))
d.rectangle((0, 0, W - 1, H - 1), outline=(30, 75, 82, 255))
d.line((1, 1, W - 2, 1), fill=(71, 177, 174, 255))
d.line((1, H - 2, W - 2, H - 2), fill=(13, 44, 52, 255))

# Left: ME repository and search header.
d.rectangle((3, 3, 190, 165), fill=(9, 20, 28, 255), outline=(35, 80, 86, 255))
d.rectangle((5, 4, 188, 16), fill=(12, 28, 36, 255))
d.line((6, 4, 187, 4), fill=(49, 130, 134, 255))
# Status lamps and title-like decorative bars.
for x, c in [(9, (72, 247, 216, 255)), (13, (42, 148, 170, 255)), (17, (30, 83, 112, 255))]:
    d.rectangle((x, 8, x + 1, 9), fill=c)
d.rectangle((23, 7, 66, 8), fill=(42, 92, 103, 255))
d.rectangle((23, 10, 54, 11), fill=(25, 60, 71, 255))
# Search field background.
d.rectangle((79, 3, 170, 16), fill=(5, 14, 21, 255), outline=(32, 93, 100, 255))
d.line((81, 4, 168, 4), fill=(17, 50, 59, 255))
# Network item slots (9 columns per row); rendered item icons sit over these wells.
for y in range(17, 71, 18):
    for col in range(9):
        x = 7 + col * 18
        d.rectangle((x, y, x + 17, y + 17), fill=(8, 18, 26, 255), outline=(28, 55, 64, 255))
        d.line((x + 1, y + 1, x + 16, y + 1), fill=(23, 42, 51, 255))
# Left scrollbar channel.
d.rectangle((174, 18, 187, 70), fill=(5, 13, 20, 255), outline=(29, 57, 65, 255))
d.rectangle((177, 21, 184, 40), fill=(23, 54, 62, 255), outline=(46, 105, 109, 255))
# Storage rows have restrained teal dividers.
for y in [17, 35, 53, 71]:
    d.line((5, y, 188, y), fill=(31, 67, 74, 255))

# Right: fixed terminal module rail and subtle separators; repeated 18px AE2 row slices tile seamlessly.
d.rectangle((194, 0, 377, H - 3), fill=(8, 20, 28, 255))
d.line((194, 1, 194, H - 3), fill=(73, 203, 190, 255))
d.line((195, 1, 195, H - 3), fill=(25, 72, 79, 255))
d.line((377, 1, 377, H - 3), fill=(32, 99, 103, 255))
# A compact top rail and a cyan rule above the crafting region.
d.rectangle((198, 4, 372, 16), fill=(10, 28, 36, 255), outline=(28, 77, 83, 255))
d.line((199, 5, 371, 5), fill=(77, 206, 193, 255))
# Five-row matrix bay is a flat bed; actual AE2 slots provide the crisp 5x5 recesses.
d.rectangle((198, 43, 301, 143), fill=(5, 15, 22, 255), outline=(34, 106, 108, 255))
d.line((199, 44, 300, 44), fill=(47, 154, 151, 255))
d.line((199, 142, 300, 142), fill=(17, 68, 76, 255))
# A second frame for the result slot and its cable-like trace.
d.rectangle((309, 78, 338, 108), fill=(7, 18, 25, 255), outline=(34, 93, 101, 255))
d.line((302, 92, 309, 92), fill=(51, 185, 177, 255))
for x in [304, 307]:
    d.point((x, 92), fill=(101, 255, 228, 255))
# A handful of subtle technical ticks on the outer rail.
for y in range(19, 168, 18):
    d.line((197, y, 199, y), fill=(61, 152, 151, 255))
    d.line((372, y, 375, y), fill=(29, 96, 102, 255))

# Bottom-left player inventory panel (AE2 anchors its slots to the lower edge).
d.rectangle((5, 98, 188, 184), fill=(8, 18, 26, 255), outline=(35, 75, 82, 255))
d.line((6, 99, 187, 99), fill=(52, 132, 134, 255))
for y in [104, 122, 140, 162]:
    cols = 9
    for col in range(cols):
        x = 7 + col * 18
        d.rectangle((x, y, x + 17, y + 17), fill=(7, 16, 23, 255), outline=(28, 54, 62, 255))
        d.line((x + 1, y + 1, x + 16, y + 1), fill=(22, 42, 49, 255))
# Small bracket accents around inventory area.
d.line((6, 101, 12, 101), fill=(105, 237, 209, 255))
d.line((181, 181, 187, 181), fill=(47, 134, 137, 255))

# Re-establish the edge rails across the entire sheet after panel fills.
d.rectangle((0, 0, W - 1, H - 1), outline=(30, 75, 82, 255))
d.line((1, 1, W - 2, 1), fill=(71, 177, 174, 255))
img.save(GUI / "mega_terminal.png")

# Fixed 5x5 crafting bay overlay. Unlike AE2's repeated storage-row slices, this widget is
# drawn once at a stable screen position and sits behind the actual menu slots.
PW, PH = 148, 106
panel = Image.new("RGBA", (PW, PH), (7, 18, 25, 255))
pd = ImageDraw.Draw(panel)
pd.rectangle((0, 0, PW - 1, PH - 1), fill=(8, 20, 28, 255), outline=(42, 112, 114, 255))
pd.line((1, 1, PW - 2, 1), fill=(98, 239, 211, 255))
pd.line((2, 3, 2, PH - 4), fill=(27, 77, 84, 255))
pd.line((PW - 3, 3, PW - 3, PH - 4), fill=(27, 77, 84, 255))
pd.line((1, PH - 2, PW - 2, PH - 2), fill=(16, 60, 68, 255))
# Matrix well: the 25 real AE2 slots are placed over this inset.
pd.rectangle((5, 7, 104, 102), fill=(5, 15, 22, 255), outline=(29, 94, 101, 255))
pd.line((6, 8, 103, 8), fill=(52, 160, 156, 255))
pd.line((6, 101, 103, 101), fill=(18, 69, 76, 255))
# Faint inner rails aligned to the 18px AE2 slot pitch.
for x in [24, 42, 60, 78, 96]:
    pd.line((x, 10, x, 98), fill=(10, 31, 39, 255))
for y in [26, 44, 62, 80, 98]:
    pd.line((7, y, 102, y), fill=(10, 31, 39, 255))
# Result well and luminous transfer arrow.
pd.rectangle((114, 36, 142, 66), fill=(5, 15, 22, 255), outline=(40, 112, 116, 255))
pd.line((115, 37, 141, 37), fill=(66, 189, 178, 255))
pd.line((104, 52, 114, 52), fill=(39, 141, 147, 255), width=2)
pd.polygon([(110, 47), (117, 52), (110, 57), (110, 54), (106, 54), (106, 50), (110, 50)],
           fill=(94, 255, 223, 255))
pd.point((108, 52), fill=(223, 255, 245, 255))
# Small status jewel in the lower corner.
pd.rectangle((131, 88, 136, 93), fill=(9, 37, 44, 255), outline=(36, 133, 131, 255))
pd.point((133, 90), fill=(104, 248, 220, 255))
panel.save(GUI / "mega_terminal_crafting_panel.png")

print(f"Wrote terminal assets to {PART} and {GUI}")
