package com.rageexxet.infinitypower.registry;

import appeng.api.parts.PartModels;
import appeng.items.parts.PartItem;
import appeng.items.parts.PartModelsHelper;
import com.rageexxet.infinitypower.InfinityPowerMod;
import com.rageexxet.infinitypower.ae2.MegaCraftingTerminalPart;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** AE2 cable-bus parts added by Infinity Power. */
public final class ModParts {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, InfinityPowerMod.MOD_ID);

    public static final RegistryObject<Item> MEGA_CRAFTING_TERMINAL = ITEMS.register(
            "mega_crafting_terminal",
            () -> new PartItem<>(new Item.Properties().stacksTo(64), MegaCraftingTerminalPart.class,
                    MegaCraftingTerminalPart::new));

    static {
        // Register the model layers before AE2 freezes its cable-bus model list.
        PartModels.registerModels(PartModelsHelper.createModels(MegaCraftingTerminalPart.class));
    }

    private ModParts() {
    }
}
