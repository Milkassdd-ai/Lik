package com.rageexxet.infinitypower.client;

import appeng.api.config.ActionItems;
import appeng.client.gui.me.common.MEStorageScreen;
import appeng.client.gui.style.ScreenStyle;
import appeng.client.gui.widgets.ActionButton;
import appeng.core.AEConfig;
import com.rageexxet.infinitypower.ae2.MegaCraftingTerminalMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** AE2 storage screen with a custom 5x5 crafting panel. */
public final class MegaCraftingTerminalScreen extends MEStorageScreen<MegaCraftingTerminalMenu> {
    public MegaCraftingTerminalScreen(MegaCraftingTerminalMenu menu, Inventory playerInventory,
            Component title, ScreenStyle style) {
        super(menu, playerInventory, title, style);

        widgets.addBackgroundPanel("craftingPanel");

        ActionButton clearGrid = new ActionButton(ActionItems.STASH, button -> menu.clearCraftingGrid());
        clearGrid.setHalfSize(true);
        widgets.add("clearCraftingGrid", clearGrid);

        ActionButton clearToPlayer = new ActionButton(ActionItems.STASH_TO_PLAYER_INV,
                button -> menu.clearToPlayerInventory());
        clearToPlayer.setHalfSize(true);
        widgets.add("clearToPlayerInv", clearToPlayer);
    }

    @Override
    public void onClose() {
        if (AEConfig.instance().isClearGridOnClose()) {
            getMenu().clearCraftingGrid();
        }
        super.onClose();
    }
}
