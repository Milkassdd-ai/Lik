package com.rageexxet.infinitypower.ae2;

import appeng.api.inventories.InternalInventory;
import appeng.api.parts.IPartItem;
import appeng.api.parts.IPartModel;
import appeng.parts.PartModel;
import appeng.parts.reporting.AbstractTerminalPart;
import appeng.util.inv.AppEngInternalInventory;
import com.rageexxet.infinitypower.InfinityPowerMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** A persistent 5x5 crafting matrix exposed as a real AE2 terminal part. */
public final class MegaCraftingTerminalPart extends AbstractTerminalPart {
    public static final int GRID_SIDE = 5;
    public static final int GRID_SIZE = GRID_SIDE * GRID_SIDE;
    public static final ResourceLocation INV_CRAFTING = InfinityPowerMod.id("mega_crafting_terminal_grid");

    @appeng.items.parts.PartModels
    public static final ResourceLocation MODEL_BASE_CUSTOM = InfinityPowerMod.id("part/mega_crafting_terminal_base");
    @appeng.items.parts.PartModels
    public static final ResourceLocation MODEL_OFF = InfinityPowerMod.id("part/mega_crafting_terminal_off");
    @appeng.items.parts.PartModels
    public static final ResourceLocation MODEL_ON = InfinityPowerMod.id("part/mega_crafting_terminal_on");

    public static final IPartModel MODELS_OFF = new PartModel(MODEL_BASE_CUSTOM, MODEL_OFF, MODEL_STATUS_OFF);
    public static final IPartModel MODELS_ON = new PartModel(MODEL_BASE_CUSTOM, MODEL_ON, MODEL_STATUS_ON);
    public static final IPartModel MODELS_HAS_CHANNEL = new PartModel(MODEL_BASE_CUSTOM, MODEL_ON,
            MODEL_STATUS_HAS_CHANNEL);

    private final AppEngInternalInventory craftingGrid = new AppEngInternalInventory(this, GRID_SIZE);

    public MegaCraftingTerminalPart(IPartItem<?> partItem) {
        super(partItem);
    }

    @Override
    public void clearContent() {
        super.clearContent();
        craftingGrid.clear();
    }

    @Override
    public void readFromNBT(CompoundTag data) {
        super.readFromNBT(data);
        craftingGrid.readFromNBT(data, "megaCraftingGrid");
    }

    @Override
    public void writeToNBT(CompoundTag data) {
        super.writeToNBT(data);
        craftingGrid.writeToNBT(data, "megaCraftingGrid");
    }

    @Override
    public void addAdditionalDrops(List<ItemStack> drops, boolean wrenched) {
        super.addAdditionalDrops(drops, wrenched);
        for (ItemStack stack : craftingGrid) {
            if (!stack.isEmpty()) {
                drops.add(stack.copy());
            }
        }
    }

    @Override
    public MenuType<?> getMenuType(Player player) {
        return MegaCraftingTerminalMenu.TYPE;
    }

    @Override
    public InternalInventory getSubInventory(ResourceLocation id) {
        if (INV_CRAFTING.equals(id)) {
            return craftingGrid;
        }
        return super.getSubInventory(id);
    }

    @Override
    public IPartModel getStaticModels() {
        return selectModel(MODELS_OFF, MODELS_ON, MODELS_HAS_CHANNEL);
    }
}
