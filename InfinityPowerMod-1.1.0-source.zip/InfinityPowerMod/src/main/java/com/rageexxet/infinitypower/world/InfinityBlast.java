package com.rageexxet.infinitypower.world;

import com.rageexxet.infinitypower.config.InfinityConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Server-side blast logic. Terrain flattening is queued and throttled to avoid a single-tick stall. */
@Mod.EventBusSubscriber(modid = "infinitypower", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class InfinityBlast {
    private static final List<FlattenJob> JOBS = new ArrayList<>();
    private static final float ENTITY_DAMAGE = 10_000.0F;

    public static void detonate(ServerLevel level, Vec3 center, BlockPos impactBlock, Entity thrower, Entity projectile) {
        int radius = InfinityConfig.PLATE_RADIUS_BLOCKS.get();
        double radiusSquared = (double) radius * radius;

        if (InfinityConfig.DAMAGE_ENTITIES.get()) {
            AABB bounds = new AABB(center.x - radius, center.y - radius, center.z - radius,
                    center.x + radius, center.y + radius, center.z + radius);
            DamageSource source = level.damageSources().explosion(projectile, thrower);
            for (Entity entity : level.getEntities((Entity) null, bounds, Entity::isAlive)) {
                if (entity == thrower || entity == projectile) continue; // The thrower is deliberately immune.
                if (entity.distanceToSqr(center) > radiusSquared) continue;
                entity.hurt(source, ENTITY_DAMAGE);
            }
        }

        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.FLASH, center.x, center.y, center.z, 1, 0, 0, 0, 0);
        level.playSound(null, impactBlock, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 4.0F, 0.65F);

        if (InfinityConfig.FLATTEN_TERRAIN.get()
                && JOBS.size() < InfinityConfig.MAX_QUEUED_FLATTEN_JOBS.get()) {
            JOBS.add(new FlattenJob(level, impactBlock.getX(), impactBlock.getZ(), impactBlock.getY(), radius));
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || JOBS.isEmpty()) return;
        int columnsRemaining = InfinityConfig.COLUMNS_PER_TICK.get();
        int blockOpsRemaining = InfinityConfig.BLOCK_UPDATES_PER_TICK.get();
        Iterator<FlattenJob> iterator = JOBS.iterator();
        while (iterator.hasNext()) {
            FlattenJob job = iterator.next();
            if (job.level.getServer() != event.getServer()) continue;
            WorkResult work = job.process(columnsRemaining, blockOpsRemaining);
            columnsRemaining -= work.columnsStarted();
            blockOpsRemaining -= work.blockOps();
            if (job.isDone()) iterator.remove();
            if (columnsRemaining <= 0 || blockOpsRemaining <= 0) break;
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        JOBS.clear();
    }

    private record WorkResult(int columnsStarted, int blockOps) {}

    private static final class FlattenJob {
        private final ServerLevel level;
        private final List<int[]> columns = new ArrayList<>();
        private final int targetY;
        private int cursor;

        private boolean activeColumn;
        private int activeX;
        private int activeZ;
        private int workY;
        private int workEnd;
        private BlockState workState;
        private BlockState capState;
        private boolean capPending;

        private FlattenJob(ServerLevel level, int centerX, int centerZ, int targetY, int radius) {
            this.level = level;
            this.targetY = Math.max(level.getMinBuildHeight() + 2,
                    Math.min(level.getMaxBuildHeight() - 2, targetY));
            long radiusSquared = (long) radius * radius;
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if ((long) dx * dx + (long) dz * dz <= radiusSquared) {
                        columns.add(new int[]{centerX + dx, centerZ + dz});
                    }
                }
            }
        }

        private WorkResult process(int maxColumns, int maxBlockOps) {
            int columnsStarted = 0;
            int blockOps = 0;
            while (blockOps < maxBlockOps && (activeColumn || columnsStarted < maxColumns)) {
                if (!activeColumn) {
                    if (cursor >= columns.size() || columnsStarted >= maxColumns) break;
                    int[] column = columns.get(cursor++);
                    columnsStarted++;
                    beginColumn(column[0], column[1]);
                    if (!activeColumn) continue;
                }

                if (workState != null && workY <= workEnd) {
                    BlockPos pos = new BlockPos(activeX, workY++, activeZ);
                    if (level.hasChunkAt(pos)) {
                        if (!workState.isAir() || !level.isEmptyBlock(pos)) {
                            level.setBlock(pos, workState, 2);
                        }
                    }
                    blockOps++;
                    continue;
                }

                if (capPending) {
                    BlockPos surface = new BlockPos(activeX, targetY, activeZ);
                    if (level.hasChunkAt(surface)) level.setBlock(surface, capState, 3);
                    capPending = false;
                    blockOps++;
                    continue;
                }

                activeColumn = false;
            }
            return new WorkResult(columnsStarted, blockOps);
        }

        private void beginColumn(int x, int z) {
            BlockPos probe = new BlockPos(x, targetY, z);
            // Do not force-load chunks; only already loaded terrain is eligible for changes.
            if (!level.hasChunkAt(probe)) return;

            activeX = x;
            activeZ = z;
            int minY = level.getMinBuildHeight() + 1;
            int maxY = level.getMaxBuildHeight() - 1;
            int planeY = Math.max(minY, Math.min(maxY, targetY));
            int highest = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
            highest = Math.max(minY, Math.min(maxY, highest));

            BlockState fillState = level.dimension() == Level.NETHER
                    ? Blocks.NETHERRACK.defaultBlockState()
                    : level.dimension() == Level.END
                    ? Blocks.END_STONE.defaultBlockState()
                    : Blocks.DIRT.defaultBlockState();
            capState = level.dimension() == Level.OVERWORLD
                    ? Blocks.GRASS_BLOCK.defaultBlockState()
                    : fillState;

            workState = null;
            workY = 1;
            workEnd = 0;
            if (highest > planeY) {
                workState = Blocks.AIR.defaultBlockState();
                workY = planeY + 1;
                workEnd = highest;
            } else if (highest < planeY) {
                workState = fillState;
                workY = highest + 1;
                workEnd = planeY - 1;
            }
            capPending = true;
            activeColumn = true;
        }

        private boolean isDone() {
            return cursor >= columns.size() && !activeColumn;
        }
    }

    private InfinityBlast() {}
}
