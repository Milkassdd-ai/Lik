package com.rageexxet.infinitypower.client;

import appeng.init.client.InitScreens;
import com.rageexxet.infinitypower.InfinityPowerMod;
import com.rageexxet.infinitypower.ae2.MegaCraftingTerminalMenu;
import com.rageexxet.infinitypower.registry.ModEntities;
import com.rageexxet.infinitypower.registry.ModParts;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = InfinityPowerMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.EXPLOSIVE_PLATE.get(), ThrownItemRenderer::new);
    }

    @SubscribeEvent
    public static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        event.register((stack, tintIndex) -> 0xFFFFFFFF, ModParts.MEGA_CRAFTING_TERMINAL.get());
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> InitScreens.<MegaCraftingTerminalMenu, MegaCraftingTerminalScreen>register(
                MegaCraftingTerminalMenu.TYPE, MegaCraftingTerminalScreen::new,
                "/screens/terminals/infinitypower_mega_crafting_terminal.json"));
    }

    private ClientModEvents() {
    }
}
