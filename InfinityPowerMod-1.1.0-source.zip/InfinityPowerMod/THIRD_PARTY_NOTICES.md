# Third-party notices

## Applied Energistics 2 (AE2)

- Project: https://github.com/AppliedEnergistics/Applied-Energistics-2
- Required runtime dependency: Applied Energistics 2 for Forge 1.20.1, version 15.4.12 or newer in the 15.x line.
- The terminal item/part models refer at runtime to AE2's existing `ae2:item/display_base`, `ae2:part/display_base`, `ae2:part/display_off`, `ae2:part/terminal_on`, and `ae2:part/display_status_*` models. These AE2 model resources are supplied by the installed AE2 mod and are **not copied into this project or its JAR**. Original Infinity Power textures and the 5×5 terminal GUI are used for the new part.
- AE2's model and texture license is CC BY-NC-SA 3.0; AE2's code is LGPL-3.0 and its API is MIT. See the upstream repository and license files for the applicable terms.

## Panel visual reference

- Repository: https://github.com/Milkassdd-ai/Panel
- Used as a visual reference for dark panels and cyan accents only. No Panel files are redistributed; no explicit license was identified in the reviewed repository snapshot.
